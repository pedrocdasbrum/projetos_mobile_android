package com.pedrocaetano.conectaiesp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;

public class HomeScreen extends AppCompatActivity {
    private EditText etName;
    private EditText etPassword;

    private Button btLogin;
    private  Button btRegister;

    public static String name;
    public static String password;

    FirebaseDatabase fb;
    DatabaseReference dr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        references();
        login();
        registration();
    }

    public void references() {
        etName = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);

        btLogin = (Button) findViewById(R.id.btLogin);
        btRegister = (Button) findViewById(R.id.btRegister);

        fb = FirebaseDatabase.getInstance();
        dr = fb.getReference();
    }

    public void login() {
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = etName.getText().toString();
                password = etPassword.getText().toString();

                login(name, password);
            }
        });
    }

    private void login(final String name, final String password) {
        dr.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("aluno").child(name).getValue() == null) {
                    Toast.makeText(HomeScreen.this, "Usuário inexistente" + "Se deseja cadastrar-se, clique no botão cadastrar-se", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (dataSnapshot.child("aluno").child(name).child("senha").getValue().equals(md5(password))) {
                        nextScreen();
                    }
                    else {
                        Toast.makeText(HomeScreen.this, "Senha incorreta",Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void nextScreen() {
        Intent it = new Intent(HomeScreen.this, UserScreen.class);
        startActivity(it);
    }

    private static final String md5(final String toEncrypt) {
        try {
            final MessageDigest digest = MessageDigest.getInstance("md5");
            digest.update(toEncrypt.getBytes());
            final byte [] bytes = digest.digest();
            final StringBuilder sb = new StringBuilder();
            for (int i = 0;  i < bytes.length; i++) {
                sb.append(String.format("%02X", bytes[i]));
            }
            return sb.toString().toLowerCase();
        }
        catch (Exception exc) {
            return "";
        }
    }

    public void registration() {
        btRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(HomeScreen.this, Registration_Screen.class);
                startActivity(it);
            }
        });
    }
}