package com.pedrocaetano.conectaiesp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;

public class Registration_Screen extends AppCompatActivity {
    private EditText etName;
    private EditText etClass;
    private EditText etYear;
    private EditText etEmail;
    private EditText etPassword;

    private Button btRegister;
    private Button btClear;

    public static String name;
    public static String password;

    FirebaseDatabase fb;
    DatabaseReference dr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration__screen);
        references();
        registration();
        clear();
    }

    public void references() {
        etName = (EditText) findViewById(R.id.etName);
        etClass = (EditText) findViewById(R.id.etClass);
        etYear = (EditText) findViewById(R.id.etYear);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);

        btRegister = (Button) findViewById(R.id.btRegister);
        btClear = (Button) findViewById(R.id.btClear);

        fb = FirebaseDatabase.getInstance();
        dr = fb.getReference();
    }

    public void registration() {
        btRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register(name, password);

                Intent it = new Intent(Registration_Screen.this, HomeScreen.class);
                startActivity(it);
                Toast.makeText(getBaseContext(), "Cadastro bem sucedido!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void register(final String name, final String password) {
        dr.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dr.child("aluno").child(name).child("nome").setValue("");
                dr.child("aluno").child(name).child("turma").setValue("");
                dr.child("aluno").child(name).child("ano letivo").setValue("");
                dr.child("aluno").child(name).child("email").setValue("");
                dr.child("aluno").child(name).child("senha").setValue(md5(password));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private static final String md5(final String toEncrypt) {
        try {
            final MessageDigest digest = MessageDigest.getInstance("md5");
            digest.update(toEncrypt.getBytes());
            final byte [] bytes = digest.digest();
            final StringBuilder sb = new StringBuilder();
            for (int i = 0;  i < bytes.length; i++) {
                sb.append(String.format("%02X", bytes[i]));
            }
            return sb.toString().toLowerCase();
        }
        catch (Exception exc) {
            return "";
        }
    }

    public void clear() {
        btClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etName.setText("");
                etClass.setText("");
                etYear.setText("");
                etEmail.setText("");
                etPassword.setText("");
            }
        });
    }
}